package modelo;


public class Destino {
	private int id_destino;	
	private String saopaulo;
	private String riodejaneiro;
	private String disney;
	private Cliente cliente;
	
	public Destino (String saopaulo, String riodejaneiro, String disney) {
		this.saopaulo = saopaulo;
		this.riodejaneiro = riodejaneiro;
		this.disney = disney;
	}

	

	String getSaopaulo() {
		return saopaulo;
	}

	void setSaopaulo(String saopaulo) {
		this.saopaulo = saopaulo;
	}

	String getRiodejaneiro() {
		return riodejaneiro;
	}

	void setRiodejaneiro(String riodejaneiro) {
		this.riodejaneiro = riodejaneiro;
	}

	String getDisney() {
		return disney;
	}

	void setDisney(String disney) {
		this.disney = disney;
	}

	Cliente getCliente() {
		return cliente;
	}

	public void mostrar() {
		System.out.println("São Paulo: " + saopaulo + "Rio de Janeiro: " + riodejaneiro + "Disney: " + disney);
	}
}
	
