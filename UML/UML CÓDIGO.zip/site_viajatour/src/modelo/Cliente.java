package modelo;

public class Cliente {
	private int id_cliente;
	private String nome;
	private String email;	
	private String endereco;
	
	public Cliente(String nome, String email, String endereco) {
		this.nome = nome;
		this.email = email;		
		this.endereco = endereco;
		
	
	}
	public Cliente() {
		
		
	}
	
	public int getId_cliente() {
		return this.id_cliente;
	}
	
	public void setId_cliente(int id_cliente) {
		this.id_cliente = id_cliente;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getEmail() {
		return this.email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getEndereco() {
		return this.endereco;
	}
	
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	public void mostrar() {
		System.out.println("nome: " + nome + " email: " + email +  " endereco: " + endereco);
	}
}
