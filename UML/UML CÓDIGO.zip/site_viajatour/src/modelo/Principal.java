package modelo;

public class Principal {

	public static void main(String[] args) {
		
		Pessoa_fisica Ricardo = new Pessoa_fisica("Ricardo", "ricardo@tal.com","Rua das Pedras, n 35", "999.999.999-99");
		Pessoa_fisica Aline = new Pessoa_fisica("Aline", "aline@tal.com","Rua das Rosas, n 17", "999.999.999-99");
		Pessoa_fisica Bruno = new Pessoa_fisica("Bruno", "bruno@tal.com","Estrada Solimões, n 365", "999.999.999-99");

		Ricardo.mostrar();
		Aline.mostrar();
		Bruno.mostrar();
	}

}
