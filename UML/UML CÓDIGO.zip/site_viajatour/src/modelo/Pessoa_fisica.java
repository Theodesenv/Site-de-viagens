package modelo;

public class Pessoa_fisica extends Cliente {
	private String cpf;
	
	public Pessoa_fisica() {
		super();
	}
		
	public Pessoa_fisica(String nome, String email, String endereco, String cpf) {
		super(nome, email, endereco);
		this.cpf = cpf;
	}
	
	public String getCpf() {
		return this.cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	
	

}
