package br.com.crude.factory;

import java.sql.DriverManager;

import com.mysql.jdbc.Connection;

public class ConnectionFactory {
	
	
	private static final String USERNAME = "root";
	
	
	private static final String PASSWORD = "12345";
	
		
	private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/crud";
	
	
	public static Connection createConnectionToMySQL() throws Exception{
		
		Class.forName("com.mysql.cj.jdbc.Driver");		
		
			
		Connection connection = 
		(Connection) DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
		
		return connection;
		
	}
	
	public static void main(String[] args) throws Exception{
		
		Connection con = createConnectionToMySQL();
		
		if(con!=null) {
			System.out.println("Conexão obtida com sucesso!");
			con.close();
		}
	}
	
	
			

}
