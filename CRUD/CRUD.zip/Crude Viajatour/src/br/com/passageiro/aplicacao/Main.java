package br.com.passageiro.aplicacao;

import br.com.agenda.dao.UsuarioDAO;
import br.com.passageiro.model.Usuario;

public class Main {

	public static void main(String[] args) {
		
		UsuarioDAO usuarioDao = new UsuarioDAO();
		
		Usuario usuario = new Usuario();
		usuario.setNome("Ricardo");
		usuario.setEndereco("Rua das Pedras");
		usuario.setEmail("ricardo@tal.com");
		
		usuarioDao.save(usuario);
		
		

	}

}
