package br.com.passageiro.model;

public class Usuario {
	
	private int id;
	private String nome;
	private String endereco;
	private String telefone;
	private String emial;
	
	
	int getId() {
		return id;
	}
	void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getTelefone() {
		return telefone;
	}
	void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	String getEmial() {
		return emial;
	}
	void setEmial(String emial) {
		this.emial = emial;
	}
	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setEmail(String string) {
		// TODO Auto-generated method stub
		
	}

}
