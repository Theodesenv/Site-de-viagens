import java.util.Scanner;

public class Crude {

	public static void main(String[] args) {
		int numero = 0;
		String nome;
		int escolha = 0;
		Scanner teclado = new Scanner(System.in);
		System.out.println("Adicione um nome: ");
		nome = teclado.nextLine();
		System.out.println("Insira a idade: ");
		numero = teclado.nextInt();
		System.out.println("O que deseja fazer? **(1) Deletar - (2)Atualizar - (3)Mostrar Cadastro - (4)Novo Cadastro**");
		escolha = teclado.nextInt();
		switch (escolha) {
		case 1:
			numero = 0;
			nome = "";
			System.out.println("Informação Deletada");
			break;
		case 2:			
			System.out.println("Escolha um novo nome: ");
			nome = teclado.nextLine();			
			System.out.println("Escolha uma nova idade: ");
			numero = teclado.nextInt();
			System.out.println("O novo usuário é "+nome+" nova idade é: "+numero);
			break;
		case 3:
			System.out.println("O usuário é "+nome+" e a idade é: "+numero);
			break;
		case 4:			
			System.out.println("Adicione um nome: ");
			nome = teclado.nextLine();
			System.out.println("Insira uma nova idade: ");
			numero = teclado.nextInt();
						
			break;
		}

	}

}
